# -*- coding: utf-8 -*-
"""
Created on Dec.15 9:38AM 2018

Full Name of code: Temporal change of spatial correlation

@author: ML
"""
#Padding  default is valid
import numpy as np
import scipy.io as sio

from keras.models import Model
from keras import backend as K
from keras import layers

from keras.layers import Input, Flatten, LSTM
from keras.layers.convolutional import Conv2D, UpSampling2D
from keras.layers.pooling import MaxPooling2D, AveragePooling2D
from keras.layers.merge import Concatenate, Average, concatenate
from keras.layers.normalization import BatchNormalization
from keras.layers.core import Activation, Dense, Dropout, Reshape, Permute, Lambda

from keras import regularizers
from keras.regularizers import Regularizer
import math
import tensorflow as tf
import scipy.io as scio
class StructuredSparse(Regularizer):

    def __init__(self, C=0.001):
        self.C = K.cast_to_floatx(C)

    def __call__(self, kernel_matrix):
        # const_coeff = np.sqrt(K.int_shape(kernel_matrix)[-1] * K.int_shape(kernel_matrix)[-2])
        return self.C * \
               K.sum(K.sqrt(K.sum(K.square(kernel_matrix), axis=-1)), axis=-1)

    def get_config(self):
        return {'C': float(self.C)}

class TCHC(object):

    def __init__(self,
                 image_size,
                 num_chns,
                 num_outputs,
                 feature_depth,
                 with_bn=True,
                 with_dropout=True,
                 region_sparse=0.001,#0.001
                 drop_prob=0.5):
        self.num_chns = num_chns
        self.num_outputs = num_outputs
        self.img_size = image_size
        self.feature_depth = feature_depth
        self.with_bn = with_bn
        self.region_sparse = region_sparse
        self.with_dropout = with_dropout
        if with_dropout:
            self.drop_prob = drop_prob



    def tchc_net(self, inputs, optimizer='Adadelta', loss='binary_crossentropy', metrics=['accuracy']):
        conv1_convs = []
        count = 0

        for i in range(self.img_size[0]):
            conv_name = 'conv1_{0}'.format(i + 1)
            conv1 = Conv2D(filters=self.feature_depth[0],
                    kernel_size=[1, 30],#30
                    strides=[1, 2],
                    padding='valid',
                    data_format='channels_last',
                    use_bias = False,
                    name=conv_name)(inputs[i])
            #if self.with_bn:
            conv1 = BatchNormalization(axis=-1)(conv1)
            conv1 = Activation('relu')(conv1)
            #if self.with_dropout:
            conv1 = Dropout(self.drop_prob)(conv1)
            conv1_convs.append(conv1)
            count +=1

        conv2_convs=[]
        for i in range(self.img_size[0]):
            conv_name = 'conv2_{0}'.format(i + 1)
            conv2 = Conv2D(filters=self.feature_depth[1],
                    kernel_size=[self.img_size[0]-1,2],#2
                    strides=[1, 1],
                    padding='valid',
                    use_bias=False,
                    data_format='channels_last',
                    name=conv_name)(conv1_convs[i])

            conv2 = BatchNormalization(axis=-1)(conv2)#(axis=1)
            conv2 = Activation('relu')(conv2)
            conv2 = Dropout(self.drop_prob)(conv2)
            conv2_convs.append(conv2)

        inputs_conv3= concatenate(conv2_convs,axis=1)#
        conv3 = Conv2D(filters=self.feature_depth[2],
                kernel_size=[1,1],
                strides=[1, 1],
                padding='valid',
                kernel_regularizer=StructuredSparse(self.region_sparse),
                use_bias=False,
                data_format='channels_last',
                name='conv3')(inputs_conv3)

        conv3 = BatchNormalization(axis=-1)(conv3)#(axis=1)
        conv3 = Activation('relu')(conv3)

        conv3 = Dropout(self.drop_prob)(conv3)

        nd = conv3.get_shape().as_list()
        conv3_reshape = Reshape((nd[1], nd[2]))(conv3)
        print(conv3_reshape.shape)

        conv3_reshape_T = Permute((2, 1), input_shape=(nd[1], nd[2]))(conv3_reshape)


        conv3_lstm = LSTM(units=self.feature_depth[3],
                          input_shape=(nd[2],nd[1]),
                          activation='tanh',
                          return_sequences=True,name='conv3_lstm')(conv3_reshape_T)

        conv3_lstm = BatchNormalization(axis=-1)(conv3_lstm)
        conv3_lstm = Dropout(self.drop_prob)(conv3_lstm)

        conv4_lstm = LSTM(units=self.feature_depth[4],activation='tanh',
                          return_sequences=True,name='conv4_lstm')(conv3_lstm)
        conv4_lstm = BatchNormalization(axis=-1)(conv4_lstm)
        conv4_lstm = Dropout(self.drop_prob)(conv4_lstm)

        conv5_lstm = LSTM(units=self.feature_depth[5],activation='tanh',
                          return_sequences=False,name='conv5_lstm')(conv4_lstm)
        conv5_lstm = BatchNormalization(axis=-1)(conv5_lstm)
        conv5_lstm = Dropout(self.drop_prob)(conv5_lstm)



        conv6_lstm = Dense(self.num_outputs, activation='sigmoid',name='conv6_lstm')(conv5_lstm)

        model = Model(inputs=inputs, outputs=[conv6_lstm])

        model.summary()

        model.compile(loss=loss, optimizer=optimizer, metrics=metrics)

        return model


if __name__ == '__main__':
    feature_depth = [16, 8, 1, 16, 8, 4]
    roi_num = 116
    tp_num = 137
    num_chns = 1
    num_outputs = 4

    input_shape = ((roi_num-1), tp_num,num_chns)
    input_list = []
    for i in range(roi_num):

        inputs = Input(shape=input_shape)
        input_list.append(inputs)

    outputs = TCHC(image_size=[roi_num, tp_num],
                   num_chns=num_chns,
                   num_outputs=num_outputs,
                   feature_depth=feature_depth,
                   with_bn=True,
                   with_dropout=True).tchc_net(input_list)


