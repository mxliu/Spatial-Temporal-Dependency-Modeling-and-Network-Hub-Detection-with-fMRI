#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Dec 18 15:46 2018

@author: ML
"""

from __future__ import print_function

import numpy as np
import tensorflow as tf
import random as rn
import os
import keras
from TCHC_NN_S_V2 import TCHC
import scipy.io as scio
from keras import backend as K
from keras.models import Model,load_model
from keras.layers import Input,Activation #,Dense, Dropout, Flatten
from keras.callbacks import ModelCheckpoint, History
from reArrange import rearrange_fit_L

import math
# ensure the reproduct


os.environ['PYTHONHASHSEED'] = '0'
np.random.seed(42)
rn.seed(12345)
session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)

tf.set_random_seed(1234)

sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
#os.environ['CUDA_VISIBLE_DEVICES'] = '0'
dataFile='Data/adni2_fmri_timeSeries'
path=''
flag=0

num_outputs=4
batch_size=16
epochs=100
roi_num=116
kfold_i=0

check_flag='val_acc'


feature_depth = [4, 2, 1, 16, 8, 4]
tp_num = 137
num_chns = 1

str1=''
for ii in feature_depth:
    str1=str1+'_'+str(ii)#output:_16_32_32_64_128_64_32
dataNew = 'Cov_HC_AD_kfold_i_'+str(kfold_i)
str1='Cov_H1_ADNI_AD_kfold_i_'+str(kfold_i)+check_flag+'_bs_'+str(batch_size)+'eps_'+str(epochs)+str1

saveModeFile=str1+'_model.h5'
saveCheckPoint=str1+'_checkPoints.h5'  
savehistory=str1+'_history.mat'
data = scio.loadmat(dataFile)#load data

timeSeries = data['timeseries']

print(timeSeries.shape)
target= data['label']-1

print(len(np.unique(target)))


test_CV_index=data['te_sub4']
print(test_CV_index.shape)
train_CV_index=data['tr_sub4']
print(train_CV_index.shape)
testing_index1=test_CV_index[kfold_i][0]

print(testing_index1)
print(testing_index1.shape)

testing_index=test_CV_index[kfold_i][0]-1
training_index=train_CV_index[kfold_i][0]-1



training_index, testing_index=[i for i in training_index],[i for i in testing_index]
#numpy.ndarray  change to list


xtem_train, y_train=timeSeries[training_index],target[training_index]
xtem_test, y_test=timeSeries[testing_index],target[testing_index]
#Get the train and test data
x_test = rearrange_fit_L(xtem_test)
x_train = rearrange_fit_L(xtem_train)



y_train_onedim = y_train
y_test_onedim = y_test



y_train = keras.utils.to_categorical(y_train, num_outputs)
y_test = keras.utils.to_categorical(y_test, num_outputs)

#x_shape=x_test.shape
input_shape = ((roi_num - 1), tp_num,num_chns)
input_list = []
for i in range(roi_num):
    inputs = Input(shape=input_shape)
    input_list.append(inputs)


model = TCHC(image_size=[roi_num, tp_num],
           num_chns=num_chns,
           num_outputs=num_outputs,
           feature_depth=feature_depth,
           with_bn=True,
           with_dropout=True).tchc_net(input_list)



checkpoint = ModelCheckpoint(filepath=saveCheckPoint, monitor=check_flag, mode='max',
                             save_best_only=True, verbose=1)

history = History()

model.fit(x_train, y_train,
        batch_size=batch_size,
        epochs=epochs,
        verbose=1,validation_split=0.2,
        callbacks=[checkpoint,history])


scio.savemat(savehistory,{'train_history': history.history})

net2 = TCHC(image_size=[roi_num, tp_num],
           num_chns=num_chns,
           num_outputs=num_outputs,
           feature_depth=feature_depth,
           with_bn=True,
           with_dropout=True).tchc_net(input_list)
net2.load_weights(saveCheckPoint)


score = net2.evaluate(x_test, y_test, verbose=0)
predict =net2.predict(x_test)

print('Test loss:', score[0])
print('Test accuracy:', score[1])

