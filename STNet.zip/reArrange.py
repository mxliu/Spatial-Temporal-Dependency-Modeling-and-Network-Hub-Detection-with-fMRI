#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Dec 18 15:46 2018

@author: ML
"""

from __future__ import print_function
import numpy as np
import math
import scipy.stats as stats

def rearrange_fit_L(timeSeries):
    A=timeSeries
    nd=A.shape
    num_chns = 1
    data_list = []
    for i in range(nd[1]):
        data = np.zeros(shape=(nd[0], (nd[1] - 1), nd[2]))
        for k in range(nd[0]):
            count = 0
            aa = A[k,i,:]
            for j in range(nd[1]):
                if (i != j):
                    bb = A[k,j,:]
                    data[k,count,:] = aa*bb
                    count +=1
        data = data.reshape(nd[0],(nd[1] - 1), nd[2],num_chns)
        data_list.append(data)

    return data_list

